using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using languidoApp.Models;

namespace languidoApp.Controllers;

public class CliffController : Controller
{
    public IActionResult personal(){
        return View();
    }
    public IActionResult educ(){
        return View();
    }
     public IActionResult Job(){
        return View();
    }
}